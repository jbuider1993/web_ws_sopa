@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.howtodoinjava.com/xml/school", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.howtodoinjava.xml.school;

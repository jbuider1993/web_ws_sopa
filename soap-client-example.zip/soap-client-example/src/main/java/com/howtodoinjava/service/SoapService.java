package com.howtodoinjava.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.howtodoinjava.repository.SoapRepository;
import com.howtodoinjava.xml.school.StudentDetailsRequest;
import com.howtodoinjava.xml.school.StudentDetailsResponse;

@Service
public class SoapService {
   //for multi web service using config url
    //call  return (R) soapConnector.callWebService(url, request);
    //String url = Config.soapSericeURL;
   @Autowired
   private SoapRepository<StudentDetailsResponse, StudentDetailsRequest> soapRepository;

   public StudentDetailsResponse getStudenDetails(String studentName) {
      StudentDetailsRequest request = new StudentDetailsRequest();
      request.setName(studentName);
      return soapRepository.getSoapService(request);
   }

}

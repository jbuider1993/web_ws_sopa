package com.howtodoinjava.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.howtodoinjava.soap.client.SOAPConnector;

@Repository
public class SoapRepository<R, T> implements ISoapRepository<R, T> {
 
    @Autowired
    private SOAPConnector soapConnector;

    @SuppressWarnings("unchecked")
    @Override
    public R getSoapService(T request) {
        return (R) soapConnector.callWebService(request);
    }

    @SuppressWarnings("unchecked")
    @Override
    public R getSoapServiceWithUrl(String url, T request) {
        return (R) soapConnector.callWebService(url, request);
    }    
}

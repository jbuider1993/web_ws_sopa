package com.howtodoinjava.repository;

public interface ISoapRepository<R, T> {      
       R getSoapService(T request);
       R getSoapServiceWithUrl(String url, T request);
}

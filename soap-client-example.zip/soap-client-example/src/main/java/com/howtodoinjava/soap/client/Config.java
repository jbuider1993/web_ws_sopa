package com.howtodoinjava.soap.client;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class Config {
  public static final String soapSericeURL = "http://localhost:8188/service/student-details";
  private static final String schoolPackage = "com.howtodoinjava.xml.school";
  private static final String studentPackage = "com.howtodoinjava.xml.courses";
    
  @Bean
  public Jaxb2Marshaller marshaller() {
    Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
    marshaller.setContextPaths(schoolPackage,studentPackage);
    return marshaller;
  }

  @Bean
  public SOAPConnector soapConnector(Jaxb2Marshaller marshaller) {
    SOAPConnector client = new SOAPConnector();
    client.setDefaultUri(soapSericeURL);
    client.setMarshaller(marshaller);
    client.setUnmarshaller(marshaller);
    return client;
  }
}
